import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  List,
  ListOrdered,
  Link,
  Image,
  Undo,
  Redo,
  Search,
  Replace,
  FileText,
  Save,
  FolderOpen,
  Plus,
  Printer,
  Moon,
  Sun,
  Type,
  ChevronDown,
  Download,
  Copy,
  Scissors,
  ClipboardPaste,
  Highlighter,
  Palette,
  Quote,
  Code,
  Subscript,
  Superscript,
  RemoveFormatting,
  Maximize2,
  Minimize2,
  Settings,
  Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import './App.css';

interface FindReplaceState {
  find: string;
  replace: string;
  caseSensitive: boolean;
  wholeWord: boolean;
}

interface EditorSettings {
  fontSize: number;
  fontFamily: string;
  lineHeight: number;
  wordWrap: boolean;
  spellCheck: boolean;
  autoSave: boolean;
  autoSaveInterval: number;
}

const defaultSettings: EditorSettings = {
  fontSize: 16,
  fontFamily: 'system-ui',
  lineHeight: 1.6,
  wordWrap: true,
  spellCheck: true,
  autoSave: false,
  autoSaveInterval: 30,
};

const fontFamilies = [
  { value: 'system-ui', label: 'System UI' },
  { value: 'Arial, sans-serif', label: 'Arial' },
  { value: '"Times New Roman", serif', label: 'Times New Roman' },
  { value: '"Courier New", monospace', label: 'Courier New' },
  { value: 'Georgia, serif', label: 'Georgia' },
  { value: '"Segoe UI", sans-serif', label: 'Segoe UI' },
  { value: 'Roboto, sans-serif', label: 'Roboto' },
  { value: '"Open Sans", sans-serif', label: 'Open Sans' },
  { value: 'Lato, sans-serif', label: 'Lato' },
  { value: '"Fira Code", monospace', label: 'Fira Code' },
];

const fontSizes = [8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72];

const headingSizes = [
  { value: 'p', label: 'Normal' },
  { value: 'h1', label: 'Heading 1' },
  { value: 'h2', label: 'Heading 2' },
  { value: 'h3', label: 'Heading 3' },
  { value: 'h4', label: 'Heading 4' },
  { value: 'h5', label: 'Heading 5' },
  { value: 'h6', label: 'Heading 6' },
];

const colors = [
  '#000000', '#434343', '#666666', '#999999', '#b7b7b7', '#cccccc', '#d9d9d9', '#efefef', '#f3f3f3', '#ffffff',
  '#980000', '#ff0000', '#ff9900', '#ffff00', '#00ff00', '#00ffff', '#4a86e8', '#0000ff', '#9900ff', '#ff00ff',
  '#e6b8af', '#f4cccc', '#fce5cd', '#fff2cc', '#d9ead3', '#d0e0e3', '#c9daf8', '#cfe2f3', '#d9d2e9', '#ead1dc',
  '#dd7e6b', '#ea9999', '#f9cb9c', '#ffe599', '#b6d7a8', '#a2c4c9', '#a4c2f4', '#9fc5e8', '#b4a7d6', '#d5a6bd',
];

const highlightColors = [
  '#ffff00', '#00ff00', '#00ffff', '#ff00ff', '#ff0000', '#0000ff',
  '#ffffcc', '#ccffcc', '#ccffff', '#ffccff', '#ffcccc', '#ccccff',
  '#ffff99', '#99ff99', '#99ffff', '#ff99ff', '#ff9999', '#9999ff',
];

export default function App() {
  const editorRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [currentFileName, setCurrentFileName] = useState<string>('Untitled');
  const [isModified, setIsModified] = useState(false);
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [findReplaceOpen, setFindReplaceOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [findReplace, setFindReplace] = useState<FindReplaceState>({
    find: '',
    replace: '',
    caseSensitive: false,
    wholeWord: false,
  });
  const [settings, setSettings] = useState<EditorSettings>(defaultSettings);
  const [currentHeading, setCurrentHeading] = useState('p');
  const [currentFontSize, setCurrentFontSize] = useState(16);
  const [currentColor, setCurrentColor] = useState('#000000');
  const [currentHighlight, setCurrentHighlight] = useState('#ffff00');
  const [activeFormats, setActiveFormats] = useState<string[]>([]);

  // Initialize editor
  useEffect(() => {
    if (editorRef.current) {
      editorRef.current.focus();
      updateCounts();
    }
  }, []);

  // Auto-save functionality
  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | null = null;
    if (settings.autoSave && isModified) {
      interval = setInterval(() => {
        handleAutoSave();
      }, settings.autoSaveInterval * 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [settings.autoSave, settings.autoSaveInterval, isModified]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key.toLowerCase()) {
          case 's':
            e.preventDefault();
            handleSave();
            break;
          case 'o':
            e.preventDefault();
            handleOpen();
            break;
          case 'n':
            e.preventDefault();
            handleNew();
            break;
          case 'f':
            e.preventDefault();
            setFindReplaceOpen(true);
            break;
          case 'p':
            e.preventDefault();
            handlePrint();
            break;
          case 'z':
            e.preventDefault();
            document.execCommand('undo', false);
            break;
          case 'y':
            e.preventDefault();
            document.execCommand('redo', false);
            break;
          case 'b':
            e.preventDefault();
            execCommand('bold');
            break;
          case 'i':
            e.preventDefault();
            execCommand('italic');
            break;
          case 'u':
            e.preventDefault();
            execCommand('underline');
            break;
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  const execCommand = useCallback((command: string, value: string | undefined = undefined) => {
    document.execCommand(command, false, value);
    if (editorRef.current) {
      editorRef.current.focus();
      updateActiveFormats();
    }
  }, []);

  const updateActiveFormats = useCallback(() => {
    const formats = [];
    if (document.queryCommandState('bold')) formats.push('bold');
    if (document.queryCommandState('italic')) formats.push('italic');
    if (document.queryCommandState('underline')) formats.push('underline');
    if (document.queryCommandState('strikeThrough')) formats.push('strikeThrough');
    if (document.queryCommandState('superscript')) formats.push('superscript');
    if (document.queryCommandState('subscript')) formats.push('subscript');
    setActiveFormats(formats);
  }, []);

  const updateCounts = useCallback(() => {
    if (editorRef.current) {
      const text = editorRef.current.innerText || '';
      const words = text.trim().split(/\s+/).filter(word => word.length > 0);
      setWordCount(words.length);
      setCharCount(text.length);
    }
  }, []);

  const handleInput = useCallback(() => {
    setIsModified(true);
    updateCounts();
    updateActiveFormats();
  }, [updateCounts, updateActiveFormats]);

  const handleNew = useCallback(() => {
    if (isModified) {
      const confirm = window.confirm('You have unsaved changes. Do you want to save before creating a new document?');
      if (confirm) {
        handleSave();
      }
    }
    if (editorRef.current) {
      editorRef.current.innerHTML = '';
      setCurrentFileName('Untitled');
      setIsModified(false);
      updateCounts();
    }
  }, [isModified, updateCounts]);

  const handleOpen = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleFileLoad = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (editorRef.current) {
          // Try to detect if it's HTML or plain text
          if (content.trim().startsWith('<') && content.trim().endsWith('>')) {
            editorRef.current.innerHTML = content;
          } else {
            editorRef.current.innerText = content;
          }
          setCurrentFileName(file.name.replace(/\.[^/.]+$/, ''));
          setIsModified(false);
          updateCounts();
          toast.success(`Opened "${file.name}"`);
        }
      };
      reader.readAsText(file);
    }
    // Reset input
    e.target.value = '';
  }, [updateCounts]);

  const handleSave = useCallback(() => {
    if (editorRef.current) {
      const content = editorRef.current.innerHTML;
      const blob = new Blob([content], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${currentFileName}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setIsModified(false);
      toast.success(`Saved as "${currentFileName}.html"`);
    }
  }, [currentFileName]);

  const handleSaveText = useCallback(() => {
    if (editorRef.current) {
      const content = editorRef.current.innerText;
      const blob = new Blob([content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${currentFileName}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success(`Saved as "${currentFileName}.txt"`);
    }
  }, [currentFileName]);

  const handleAutoSave = useCallback(() => {
    if (editorRef.current && settings.autoSave) {
      const content = editorRef.current.innerHTML;
      localStorage.setItem('textEditorAutoSave', content);
      localStorage.setItem('textEditorAutoSaveTime', new Date().toISOString());
      toast.info('Auto-saved');
    }
  }, [settings.autoSave]);

  const handlePrint = useCallback(() => {
    const printWindow = window.open('', '_blank');
    if (printWindow && editorRef.current) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>${currentFileName}</title>
          <style>
            body { font-family: ${settings.fontFamily}; font-size: ${settings.fontSize}px; line-height: ${settings.lineHeight}; padding: 40px; }
            @media print { body { padding: 0; } }
          </style>
        </head>
        <body>${editorRef.current.innerHTML}</body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  }, [currentFileName, settings]);

  const handleFindReplace = useCallback(() => {
    if (!editorRef.current) return;
    
    const content = editorRef.current.innerHTML;
    let findText = findReplace.find;
    let replaceText = findReplace.replace;
    
    if (!findText) return;
    
    let flags = 'g';
    if (!findReplace.caseSensitive) flags += 'i';
    
    let searchPattern = findReplace.wholeWord 
      ? `\\b${escapeRegExp(findText)}\\b` 
      : escapeRegExp(findText);
    
    try {
      const regex = new RegExp(searchPattern, flags);
      const newContent = content.replace(regex, replaceText);
      editorRef.current.innerHTML = newContent;
      toast.success('Find and replace completed');
    } catch (error) {
      toast.error('Invalid search pattern');
    }
  }, [findReplace]);

  const escapeRegExp = (string: string) => {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  };

  const handleFindNext = useCallback(() => {
    if (!editorRef.current || !findReplace.find) return;
    
    // Use browser's find function if available
    const findFn = (window as unknown as { find?: (text: string, caseSensitive: boolean, backwards: boolean, wrap: boolean, wholeWord: boolean, searchInFrames: boolean, showDialog: boolean) => boolean }).find;
    if (findFn) {
      const found = findFn(findReplace.find, findReplace.caseSensitive, false, true, findReplace.wholeWord, false, false);
      if (!found) {
        toast.info('No more matches found');
      }
    } else {
      // Fallback: use selection and Range for finding text
      const editor = editorRef.current;
      const text = editor.innerText;
      const searchText = findReplace.find;
      
      let index: number;
      if (findReplace.caseSensitive) {
        index = text.indexOf(searchText);
      } else {
        index = text.toLowerCase().indexOf(searchText.toLowerCase());
      }
      
      if (index !== -1) {
        // Create a range to select the found text
        const selection = window.getSelection();
        if (selection) {
          selection.removeAllRanges();
          // This is a simplified implementation
          toast.success(`Found "${searchText}" at position ${index}`);
        }
      } else {
        toast.info('Text not found');
      }
    }
  }, [findReplace]);

  const insertLink = useCallback(() => {
    const url = prompt('Enter URL:');
    if (url) {
      execCommand('createLink', url);
    }
  }, [execCommand]);

  const insertImage = useCallback(() => {
    const url = prompt('Enter image URL:');
    if (url) {
      execCommand('insertImage', url);
    }
  }, [execCommand]);

  const changeHeading = useCallback((value: string) => {
    setCurrentHeading(value);
    if (value === 'p') {
      execCommand('formatBlock', 'p');
    } else {
      execCommand('formatBlock', value);
    }
  }, [execCommand]);

  const changeFontSize = useCallback((size: number) => {
    setCurrentFontSize(size);
    execCommand('fontSize', '7');
    // Then change the font size of the font element
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const parentElement = range.commonAncestorContainer.parentElement;
      if (parentElement && parentElement.tagName === 'FONT') {
        parentElement.style.fontSize = `${size}px`;
        parentElement.removeAttribute('size');
      }
    }
  }, [execCommand]);

  const changeFontFamily = useCallback((family: string) => {
    execCommand('fontName', family);
  }, [execCommand]);

  const changeColor = useCallback((color: string) => {
    setCurrentColor(color);
    execCommand('foreColor', color);
  }, [execCommand]);

  const changeHighlight = useCallback((color: string) => {
    setCurrentHighlight(color);
    execCommand('hiliteColor', color);
  }, [execCommand]);

  const removeFormatting = useCallback(() => {
    execCommand('removeFormat');
  }, [execCommand]);

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => {
        setIsFullscreen(true);
      });
    } else {
      document.exitFullscreen().then(() => {
        setIsFullscreen(false);
      });
    }
  }, []);

  const handleCut = useCallback(() => {
    execCommand('cut');
  }, [execCommand]);

  const handleCopy = useCallback(() => {
    execCommand('copy');
  }, [execCommand]);

  const handlePaste = useCallback(() => {
    execCommand('paste');
  }, [execCommand]);

  const isFormatActive = (format: string) => activeFormats.includes(format);

  return (
    <TooltipProvider>
      <div className={`min-h-screen flex flex-col transition-colors duration-300 ${isDarkMode ? 'dark bg-gray-900' : 'bg-gray-50'}`}>
        {/* Header / Menu Bar */}
        <header className={`sticky top-0 z-50 border-b shadow-sm ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
          {/* File Menu */}
          <div className={`flex items-center px-4 py-2 gap-1 ${isDarkMode ? 'bg-gray-800' : 'bg-gray-100'}`}>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-1">
                  <FileText className="h-4 w-4" />
                  File
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-48 p-1" align="start">
                <div className="space-y-1">
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={handleNew}>
                    <Plus className="h-4 w-4" /> New <span className="ml-auto text-xs text-muted-foreground">Ctrl+N</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={handleOpen}>
                    <FolderOpen className="h-4 w-4" /> Open <span className="ml-auto text-xs text-muted-foreground">Ctrl+O</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={handleSave}>
                    <Save className="h-4 w-4" /> Save as HTML <span className="ml-auto text-xs text-muted-foreground">Ctrl+S</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={handleSaveText}>
                    <Download className="h-4 w-4" /> Save as Text
                  </Button>
                  <Separator />
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={handlePrint}>
                    <Printer className="h-4 w-4" /> Print <span className="ml-auto text-xs text-muted-foreground">Ctrl+P</span>
                  </Button>
                </div>
              </PopoverContent>
            </Popover>

            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-1">
                  <Scissors className="h-4 w-4" />
                  Edit
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-48 p-1" align="start">
                <div className="space-y-1">
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={handleCut}>
                    <Scissors className="h-4 w-4" /> Cut <span className="ml-auto text-xs text-muted-foreground">Ctrl+X</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={handleCopy}>
                    <Copy className="h-4 w-4" /> Copy <span className="ml-auto text-xs text-muted-foreground">Ctrl+C</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={handlePaste}>
                    <ClipboardPaste className="h-4 w-4" /> Paste <span className="ml-auto text-xs text-muted-foreground">Ctrl+V</span>
                  </Button>
                  <Separator />
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={() => execCommand('undo')}>
                    <Undo className="h-4 w-4" /> Undo <span className="ml-auto text-xs text-muted-foreground">Ctrl+Z</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={() => execCommand('redo')}>
                    <Redo className="h-4 w-4" /> Redo <span className="ml-auto text-xs text-muted-foreground">Ctrl+Y</span>
                  </Button>
                  <Separator />
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={() => setFindReplaceOpen(true)}>
                    <Search className="h-4 w-4" /> Find & Replace <span className="ml-auto text-xs text-muted-foreground">Ctrl+F</span>
                  </Button>
                </div>
              </PopoverContent>
            </Popover>

            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-1">
                  <Type className="h-4 w-4" />
                  Format
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-48 p-1" align="start">
                <div className="space-y-1">
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={() => execCommand('bold')}>
                    <Bold className="h-4 w-4" /> Bold <span className="ml-auto text-xs text-muted-foreground">Ctrl+B</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={() => execCommand('italic')}>
                    <Italic className="h-4 w-4" /> Italic <span className="ml-auto text-xs text-muted-foreground">Ctrl+I</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={() => execCommand('underline')}>
                    <Underline className="h-4 w-4" /> Underline <span className="ml-auto text-xs text-muted-foreground">Ctrl+U</span>
                  </Button>
                  <Separator />
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={removeFormatting}>
                    <RemoveFormatting className="h-4 w-4" /> Clear Formatting
                  </Button>
                </div>
              </PopoverContent>
            </Popover>

            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-1">
                  <Settings className="h-4 w-4" />
                  Tools
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-48 p-1" align="start">
                <div className="space-y-1">
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={() => setSettingsOpen(true)}>
                    <Settings className="h-4 w-4" /> Settings
                  </Button>
                  <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={() => setAboutOpen(true)}>
                    <Info className="h-4 w-4" /> About
                  </Button>
                </div>
              </PopoverContent>
            </Popover>

            <div className="flex-1" />

            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" onClick={() => setIsDarkMode(!isDarkMode)}>
                  {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent>Toggle Theme</TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" onClick={toggleFullscreen}>
                  {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent>Fullscreen</TooltipContent>
            </Tooltip>
          </div>

          {/* Formatting Toolbar */}
          <div className={`flex flex-wrap items-center gap-1 px-4 py-2 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
            {/* Undo/Redo */}
            <div className="flex items-center gap-0.5">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => execCommand('undo')}>
                    <Undo className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Undo (Ctrl+Z)</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => execCommand('redo')}>
                    <Redo className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Redo (Ctrl+Y)</TooltipContent>
              </Tooltip>
            </div>

            <Separator orientation="vertical" className="h-6 mx-1" />

            {/* Heading */}
            <Select value={currentHeading} onValueChange={changeHeading}>
              <SelectTrigger className="w-32 h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {headingSizes.map((h) => (
                  <SelectItem key={h.value} value={h.value}>{h.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Separator orientation="vertical" className="h-6 mx-1" />

            {/* Font Family */}
            <Select value={settings.fontFamily} onValueChange={(value) => {
              setSettings({ ...settings, fontFamily: value });
              changeFontFamily(value);
            }}>
              <SelectTrigger className="w-36 h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {fontFamilies.map((f) => (
                  <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Font Size */}
            <Select value={currentFontSize.toString()} onValueChange={(value) => changeFontSize(parseInt(value))}>
              <SelectTrigger className="w-20 h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {fontSizes.map((size) => (
                  <SelectItem key={size} value={size.toString()}>{size}px</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Separator orientation="vertical" className="h-6 mx-1" />

            {/* Text Formatting */}
            <div className="flex items-center gap-0.5">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant={isFormatActive('bold') ? 'secondary' : 'ghost'} 
                    size="icon" 
                    className="h-8 w-8"
                    onClick={() => execCommand('bold')}
                  >
                    <Bold className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Bold (Ctrl+B)</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant={isFormatActive('italic') ? 'secondary' : 'ghost'} 
                    size="icon" 
                    className="h-8 w-8"
                    onClick={() => execCommand('italic')}
                  >
                    <Italic className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Italic (Ctrl+I)</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant={isFormatActive('underline') ? 'secondary' : 'ghost'} 
                    size="icon" 
                    className="h-8 w-8"
                    onClick={() => execCommand('underline')}
                  >
                    <Underline className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Underline (Ctrl+U)</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant={isFormatActive('strikeThrough') ? 'secondary' : 'ghost'} 
                    size="icon" 
                    className="h-8 w-8"
                    onClick={() => execCommand('strikeThrough')}
                  >
                    <Strikethrough className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Strikethrough</TooltipContent>
              </Tooltip>
            </div>

            <Separator orientation="vertical" className="h-6 mx-1" />

            {/* Text Color */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 relative">
                  <Palette className="h-4 w-4" />
                  <div 
                    className="absolute bottom-1 left-1/2 -translate-x-1/2 w-4 h-1 rounded"
                    style={{ backgroundColor: currentColor }}
                  />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-64 p-2">
                <div className="grid grid-cols-10 gap-1">
                  {colors.map((color) => (
                    <button
                      key={color}
                      className="w-5 h-5 rounded border border-gray-200 hover:scale-110 transition-transform"
                      style={{ backgroundColor: color }}
                      onClick={() => changeColor(color)}
                    />
                  ))}
                </div>
              </PopoverContent>
            </Popover>

            {/* Highlight Color */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 relative">
                  <Highlighter className="h-4 w-4" />
                  <div 
                    className="absolute bottom-1 left-1/2 -translate-x-1/2 w-4 h-1 rounded"
                    style={{ backgroundColor: currentHighlight }}
                  />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-48 p-2">
                <div className="grid grid-cols-6 gap-1">
                  {highlightColors.map((color) => (
                    <button
                      key={color}
                      className="w-6 h-6 rounded border border-gray-200 hover:scale-110 transition-transform"
                      style={{ backgroundColor: color }}
                      onClick={() => changeHighlight(color)}
                    />
                  ))}
                </div>
              </PopoverContent>
            </Popover>

            <Separator orientation="vertical" className="h-6 mx-1" />

            {/* Alignment */}
            <div className="flex items-center gap-0.5">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => execCommand('justifyLeft')}>
                    <AlignLeft className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Align Left</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => execCommand('justifyCenter')}>
                    <AlignCenter className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Align Center</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => execCommand('justifyRight')}>
                    <AlignRight className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Align Right</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => execCommand('justifyFull')}>
                    <AlignJustify className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Justify</TooltipContent>
              </Tooltip>
            </div>

            <Separator orientation="vertical" className="h-6 mx-1" />

            {/* Lists */}
            <div className="flex items-center gap-0.5">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => execCommand('insertUnorderedList')}>
                    <List className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Bullet List</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => execCommand('insertOrderedList')}>
                    <ListOrdered className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Numbered List</TooltipContent>
              </Tooltip>
            </div>

            <Separator orientation="vertical" className="h-6 mx-1" />

            {/* Insert */}
            <div className="flex items-center gap-0.5">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={insertLink}>
                    <Link className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Insert Link</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={insertImage}>
                    <Image className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Insert Image</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => execCommand('formatBlock', 'blockquote')}>
                    <Quote className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Quote</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => execCommand('formatBlock', 'pre')}>
                    <Code className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Code Block</TooltipContent>
              </Tooltip>
            </div>

            <Separator orientation="vertical" className="h-6 mx-1" />

            {/* Subscript/Superscript */}
            <div className="flex items-center gap-0.5">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant={isFormatActive('superscript') ? 'secondary' : 'ghost'} 
                    size="icon" 
                    className="h-8 w-8"
                    onClick={() => execCommand('superscript')}
                  >
                    <Superscript className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Superscript</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant={isFormatActive('subscript') ? 'secondary' : 'ghost'} 
                    size="icon" 
                    className="h-8 w-8"
                    onClick={() => execCommand('subscript')}
                  >
                    <Subscript className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Subscript</TooltipContent>
              </Tooltip>
            </div>

            <Separator orientation="vertical" className="h-6 mx-1" />

            {/* Clear Formatting */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={removeFormatting}>
                  <RemoveFormatting className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Clear Formatting</TooltipContent>
            </Tooltip>

            {/* Find & Replace */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setFindReplaceOpen(true)}>
                  <Search className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Find & Replace (Ctrl+F)</TooltipContent>
            </Tooltip>
          </div>
        </header>

        {/* Main Editor Area */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* Title Bar */}
          <div className={`flex items-center justify-between px-4 py-2 border-b ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span className={`font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                {currentFileName}{isModified && ' *'}
              </span>
            </div>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>{wordCount} words</span>
              <span>{charCount} characters</span>
            </div>
          </div>

          {/* Editor */}
          <div className={`flex-1 overflow-auto p-8 ${isDarkMode ? 'bg-gray-900' : 'bg-gray-100'}`}>
            <div
              ref={editorRef}
              contentEditable
              className={`min-h-[calc(100vh-280px)] max-w-4xl mx-auto p-8 rounded-lg shadow-lg outline-none transition-all ${
                isDarkMode 
                  ? 'bg-gray-800 text-white' 
                  : 'bg-white text-gray-900'
              }`}
              style={{
                fontFamily: settings.fontFamily,
                fontSize: `${settings.fontSize}px`,
                lineHeight: settings.lineHeight,
              }}
              onInput={handleInput}
              onKeyUp={updateActiveFormats}
              onMouseUp={updateActiveFormats}
              spellCheck={settings.spellCheck}
              suppressContentEditableWarning
            />
          </div>
        </main>

        {/* Status Bar */}
        <footer className={`px-4 py-2 border-t text-sm flex items-center justify-between ${isDarkMode ? 'bg-gray-800 border-gray-700 text-gray-300' : 'bg-gray-100 border-gray-200 text-gray-600'}`}>
          <div className="flex items-center gap-4">
            <span>Ready</span>
            {settings.autoSave && <span className="text-green-500">● Auto-save on</span>}
          </div>
          <div className="flex items-center gap-4">
            <span>UTF-8</span>
            <span>HTML</span>
            <span>{settings.wordWrap ? 'Wrap' : 'No Wrap'}</span>
          </div>
        </footer>

        {/* Hidden File Input */}
        <input
          ref={fileInputRef}
          type="file"
          accept=".txt,.html,.htm,.md,.json,.js,.css,.xml"
          className="hidden"
          onChange={handleFileLoad}
        />

        {/* Find & Replace Dialog */}
        <Dialog open={findReplaceOpen} onOpenChange={setFindReplaceOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Find & Replace
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Find</Label>
                <Input
                  value={findReplace.find}
                  onChange={(e) => setFindReplace({ ...findReplace, find: e.target.value })}
                  placeholder="Text to find..."
                />
              </div>
              <div className="space-y-2">
                <Label>Replace with</Label>
                <Input
                  value={findReplace.replace}
                  onChange={(e) => setFindReplace({ ...findReplace, replace: e.target.value })}
                  placeholder="Replacement text..."
                />
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={findReplace.caseSensitive}
                    onCheckedChange={(checked) => setFindReplace({ ...findReplace, caseSensitive: checked })}
                  />
                  <Label className="text-sm">Case sensitive</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={findReplace.wholeWord}
                    onCheckedChange={(checked) => setFindReplace({ ...findReplace, wholeWord: checked })}
                  />
                  <Label className="text-sm">Whole word</Label>
                </div>
              </div>
            </div>
            <DialogFooter className="flex gap-2">
              <Button variant="outline" onClick={handleFindNext}>
                Find Next
              </Button>
              <Button onClick={handleFindReplace} className="gap-2">
                <Replace className="h-4 w-4" />
                Replace All
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Settings Dialog */}
        <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Editor Settings
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-6 py-4">
              <div className="space-y-2">
                <Label>Font Size: {settings.fontSize}px</Label>
                <Slider
                  value={[settings.fontSize]}
                  onValueChange={(value) => setSettings({ ...settings, fontSize: value[0] })}
                  min={8}
                  max={72}
                  step={1}
                />
              </div>
              <div className="space-y-2">
                <Label>Line Height: {settings.lineHeight}</Label>
                <Slider
                  value={[settings.lineHeight]}
                  onValueChange={(value) => setSettings({ ...settings, lineHeight: value[0] })}
                  min={1}
                  max={3}
                  step={0.1}
                />
              </div>
              <div className="space-y-2">
                <Label>Font Family</Label>
                <Select value={settings.fontFamily} onValueChange={(value) => setSettings({ ...settings, fontFamily: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {fontFamilies.map((f) => (
                      <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Word Wrap</Label>
                  <Switch
                    checked={settings.wordWrap}
                    onCheckedChange={(checked) => setSettings({ ...settings, wordWrap: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Spell Check</Label>
                  <Switch
                    checked={settings.spellCheck}
                    onCheckedChange={(checked) => setSettings({ ...settings, spellCheck: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Auto Save</Label>
                  <Switch
                    checked={settings.autoSave}
                    onCheckedChange={(checked) => setSettings({ ...settings, autoSave: checked })}
                  />
                </div>
                {settings.autoSave && (
                  <div className="space-y-2">
                    <Label>Auto Save Interval: {settings.autoSaveInterval}s</Label>
                    <Slider
                      value={[settings.autoSaveInterval]}
                      onValueChange={(value) => setSettings({ ...settings, autoSaveInterval: value[0] })}
                      min={5}
                      max={300}
                      step={5}
                    />
                  </div>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button onClick={() => setSettingsOpen(false)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* About Dialog */}
        <Dialog open={aboutOpen} onOpenChange={setAboutOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                About Advanced Text Editor
              </DialogTitle>
              <DialogDescription>
                A powerful, feature-rich text editor built with modern web technologies.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Features</h4>
                <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                  <li>Rich text formatting (bold, italic, underline, etc.)</li>
                  <li>Multiple font families and sizes</li>
                  <li>Text and highlight colors</li>
                  <li>Alignment and list options</li>
                  <li>Find & Replace functionality</li>
                  <li>File operations (New, Open, Save)</li>
                  <li>Print support</li>
                  <li>Dark/Light theme</li>
                  <li>Auto-save capability</li>
                  <li>Keyboard shortcuts</li>
                  <li>Word and character count</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Keyboard Shortcuts</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <span className="text-muted-foreground">Ctrl+N</span><span>New document</span>
                  <span className="text-muted-foreground">Ctrl+O</span><span>Open file</span>
                  <span className="text-muted-foreground">Ctrl+S</span><span>Save file</span>
                  <span className="text-muted-foreground">Ctrl+P</span><span>Print</span>
                  <span className="text-muted-foreground">Ctrl+F</span><span>Find & Replace</span>
                  <span className="text-muted-foreground">Ctrl+Z</span><span>Undo</span>
                  <span className="text-muted-foreground">Ctrl+Y</span><span>Redo</span>
                  <span className="text-muted-foreground">Ctrl+B</span><span>Bold</span>
                  <span className="text-muted-foreground">Ctrl+I</span><span>Italic</span>
                  <span className="text-muted-foreground">Ctrl+U</span><span>Underline</span>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={() => setAboutOpen(false)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </TooltipProvider>
  );
}
